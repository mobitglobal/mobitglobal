Sample configuration files for:

SystemD: mobitglobald.service
Upstart: mobitglobald.conf
OpenRC:  mobitglobald.openrc
         mobitglobald.openrcconf
CentOS:  mobitglobald.init
OS X:    org.mobitglobal.mobitglobald.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
